/**
* Plugin Name: SW Post Elements
* Plugin URI: https://codecanyon.net/item/post-elements-plugin-elementor-addon-for-blog-newspaper-magazine/33994050
* Description: A powerful Elementor addon for any blog, news, newspaper, or magazine WordPress website. It will help to showcase the blog posts, images, and post categories beautifully with different styles.
* Author:      WpThemeGo
* Author URI:  https://wpthemego.com/
* Version:     1.0.1
* Text Domain: sw-post-elements
* Requires PHP: 5.6
*/
