/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'icomoon\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-align-justify': '&#xe91c;',
		'icon-align-left': '&#xe91d;',
		'icon-align-right': '&#xe91e;',
		'icon-arrow-left': '&#xe918;',
		'icon-arrow-left-circle': '&#xe91f;',
		'icon-arrow-right': '&#xe919;',
		'icon-arrow-right-circle': '&#xe920;',
		'icon-calendar': '&#xe938;',
		'icon-check': '&#xe921;',
		'icon-check-circle': '&#xe91b;',
		'icon-check-square': '&#xe923;',
		'icon-chevron-left': '&#xe901;',
		'icon-chevron-right': '&#xe902;',
		'icon-clock': '&#xe904;',
		'icon-eye': '&#xe905;',
		'icon-facebook': '&#xe906;',
		'icon-folder': '&#xe939;',
		'icon-gift': '&#xe93a;',
		'icon-grid': '&#xe940;',
		'icon-headphones': '&#xe924;',
		'icon-heart': '&#xe907;',
		'icon-help-circle': '&#xe925;',
		'icon-home': '&#xe926;',
		'icon-info': '&#xe927;',
		'icon-instagram': '&#xe91a;',
		'icon-key': '&#xe93c;',
		'icon-layers': '&#xe900;',
		'icon-life-buoy': '&#xe93b;',
		'icon-link': '&#xe922;',
		'icon-link-2': '&#xe928;',
		'icon-linkedin': '&#xe908;',
		'icon-list': '&#xe93d;',
		'icon-lock': '&#xe93e;',
		'icon-log-in': '&#xe929;',
		'icon-log-out': '&#xe92a;',
		'icon-mail': '&#xe909;',
		'icon-map-pin': '&#xe90a;',
		'icon-menu': '&#xe903;',
		'icon-message-circle': '&#xe92b;',
		'icon-message-square': '&#xe92c;',
		'icon-minus': '&#xe92d;',
		'icon-minus-circle': '&#xe92e;',
		'icon-phone': '&#xe90b;',
		'icon-phone-call': '&#xe90c;',
		'icon-play': '&#xe92f;',
		'icon-play-circle': '&#xe930;',
		'icon-plus': '&#xe931;',
		'icon-plus-circle': '&#xe932;',
		'icon-refresh-ccw': '&#xe90d;',
		'icon-refresh-cw': '&#xe90e;',
		'icon-repeat': '&#xe90f;',
		'icon-search': '&#xe910;',
		'icon-send': '&#xe911;',
		'icon-settings': '&#xe933;',
		'icon-shopping-bag': '&#xe912;',
		'icon-shopping-cart': '&#xe913;',
		'icon-star': '&#xe934;',
		'icon-trash': '&#xe935;',
		'icon-trash-2': '&#xe914;',
		'icon-truck': '&#xe936;',
		'icon-twitter': '&#xe915;',
		'icon-user': '&#xe916;',
		'icon-x': '&#xe937;',
		'icon-x-circle': '&#xe93f;',
		'icon-youtube': '&#xe917;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
