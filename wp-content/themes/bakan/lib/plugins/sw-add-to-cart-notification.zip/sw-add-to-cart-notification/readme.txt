/**
* Plugin Name: SW Add To Cart Notification
* Plugin URI:  
* Description: An ultimate addon for Woocommerce.
* Author:      YouTech
* Author URI:  https://wpthemego.com/
* Version:     1.0.0
* Text Domain: sw-woo-elements
* Requires PHP: 5.6
*/
