/**
* Plugin Name: SW Woo Elements
* Plugin URI:  
* Description: An ultimate addon for Elementor Page Builder.
* Author:      YouTech
* Author URI:  https://wpthemego.com/
* Version:     1.0.0
* Text Domain: sw-woo-elements
* Requires PHP: 5.6
*/
